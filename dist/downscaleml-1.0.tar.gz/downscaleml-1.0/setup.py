# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['downscaleml', 'downscaleml.core', 'downscaleml.main']

package_data = \
{'': ['*']}

install_requires = \
['dask==2023.3.2',
 'joblib==1.2.0',
 'numpy==1.24.2',
 'pandas==1.5.3',
 'scikit-learn==1.2.2',
 'setuptools==66.0.0',
 'torch==2.0.0',
 'xarray==2023.3.0']

setup_kwargs = {
    'name': 'downscaleml',
    'version': '1.0',
    'description': 'downScale climate data using ML',
    'long_description': '# downscaleml\nFirst information first!\nThe dist folder contains the **\'\'downscaleml"** package, install it using `pip install downscaleml-1.0.tar.gz`. Make sure you already have GDAL dependencies installed in your conda/venv/any_environments. If suppose you face problems with the GDAL installation in your system as well as in your environment, don\'t worry, I am here for you.\n\nThis package requires GDAL==3.4.3. \n\nFollow this link to keep your GDAL installation clean and working:\nhttps://mothergeo-py.readthedocs.io/en/latest/development/how-to/gdal-ubuntu-pkg.html\n\nYou could also probably face a problem similar to what i faced, after installation of GDAL, it\'s the **libstdc++.so.6** linkage problem. This is to do with either **path linking** or **file missing in the directory**. This file has to be found in your system and to be linked with the virtual environment you are working. This can be done by just following **stackoverflow**. I can drop a little clue, which can help you in linking, kindly change the paths relative to your system.\n`ln -sf /usr/lib/x86_64-linux-gnu/libstdc++.so.6 /home/anavani/anaconda3/envs/dmcgb/bin/../lib/libstdc++.so.6` \n\nYou could also follow compatibility issue beterrn GDAL and Numpy or GDAL array now, you could arrest this issue by following the process:-\n\n`pip uninstall gdal`\n`pip install numpy`\n`pip install GDAL==$(gdal-config --version) --global-option=build_ext --global-option="-I/usr/include/gdal"`\n\n# Recommended steps to get going!\n\n1. Clone the git project in your local.\n2. `pip install poetry` in your virtual environment\n3. `poetry install` in the project local with the same local environment\n\nYou are good to go exploring\n\n## Additional Information\n\nThe data is not provided in this package, the paths for the input-output data is provided in the `downscaleml/core/inputoutput.py`. You can make necessary changes here to reflect elsewhere in the project.',
    'author': 'Suriyah Dhinakaran',
    'author_email': 'pythonsuriyah@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
